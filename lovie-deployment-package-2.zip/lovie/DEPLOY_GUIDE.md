# 🌸 Lovie App — Complete Publishing Guide

## What's in this package

```
lovie/
├── index.html              ← App entry point
├── package.json            ← Dependencies
├── vite.config.js          ← Build tool config
├── tailwind.config.js      ← Styling config
├── postcss.config.js       ← CSS processing
├── vercel.json             ← Vercel deployment config
├── .gitignore              ← Git ignore rules
├── .env.example            ← API key template
├── public/
│   └── manifest.json       ← PWA config (makes it installable)
└── src/
    ├── main.jsx            ← React entry
    ├── index.css           ← Global styles
    └── App.jsx             ← ← PASTE YOUR LOVIE CODE HERE
```

---

## STEP 1 — Set Up Locally

### Install Node.js (if you haven't)
Download from: https://nodejs.org (choose LTS version)

### Install the project
```bash
# Navigate to the lovie folder
cd lovie

# Install all dependencies
npm install
```

### Add your API key
```bash
# Copy the example file
cp .env.example .env

# Open .env and paste your Anthropic API key
# Get it free at: https://console.anthropic.com
VITE_ANTHROPIC_API_KEY=sk-ant-xxxxxxxx
```

### Paste your Lovie code
- Open `src/App.jsx`
- Paste the full Lovie React component code inside

### Run locally
```bash
npm run dev
# Opens at: http://localhost:5173
```

---

## STEP 2 — Push to GitHub

### Create a GitHub account
Go to: https://github.com and sign up (free)

### Create a new repository
1. Click the **+** icon → **New repository**
2. Name it: `lovie-app`
3. Set to **Public** (required for free Vercel)
4. Click **Create repository**

### Upload your code
```bash
# Inside your lovie folder:
git init
git add .
git commit -m "🌸 Launch Lovie App"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/lovie-app.git
git push -u origin main
```

---

## STEP 3 — Deploy on Vercel (Free Web Hosting)

1. Go to: **https://vercel.com**
2. Click **Sign Up** → Continue with GitHub
3. Click **Add New Project**
4. Select your **lovie-app** repository
5. Vercel auto-detects Vite — click **Deploy**
6. Wait ~60 seconds ✅

### Add your API key to Vercel
1. Go to your project → **Settings** → **Environment Variables**
2. Add:
   - Name: `VITE_ANTHROPIC_API_KEY`
   - Value: `your-api-key-here`
3. Click **Save** → **Redeploy**

### Your app is now live at:
```
https://lovie-app.vercel.app
```
(You can set a custom domain too!)

---

## STEP 4 — Make it Installable on Phone (PWA)

The `manifest.json` is already included! To make users able to install Lovie on their phone:

### On iPhone (Safari):
1. Open your Vercel URL in Safari
2. Tap the **Share** button
3. Tap **Add to Home Screen**
4. Name it "Lovie" → **Add**
5. It appears on home screen like a real app! 📱

### On Android (Chrome):
1. Open your URL in Chrome
2. Tap the **three dots** menu
3. Tap **Add to Home Screen** or **Install App**

---

## STEP 5 — Publish as Native App (Optional)

### Using Capacitor (React → iOS/Android)

```bash
# Install Capacitor
npm install @capacitor/core @capacitor/cli
npm install @capacitor/ios @capacitor/android

# Initialize
npx cap init Lovie com.yourname.lovie

# Build the web app first
npm run build

# Add platforms
npx cap add ios
npx cap add android

# Sync
npx cap sync

# Open in Xcode (Mac required for iOS)
npx cap open ios

# Open in Android Studio
npx cap open android
```

### App Store Requirements
| Platform | Cost | Requirements |
|----------|------|--------------|
| Apple App Store | $99/year | Mac computer, Xcode, Apple Developer account |
| Google Play Store | $25 one-time | Android Studio, Google Play Console account |

---

## STEP 6 — Custom Domain (Optional)

### Buy a domain
- **Namecheap**: https://namecheap.com (~$10/year)
- **GoDaddy**: https://godaddy.com
- Suggestion: `lovie.app` or `getlovie.com`

### Connect to Vercel
1. Vercel Dashboard → Your Project → **Settings** → **Domains**
2. Add your domain
3. Follow the DNS instructions (takes ~10 mins)

---

## Quick Deployment Checklist

- [ ] Node.js installed
- [ ] `npm install` run
- [ ] `.env` file created with API key
- [ ] Lovie code pasted into `src/App.jsx`
- [ ] `npm run dev` works locally
- [ ] GitHub repo created & code pushed
- [ ] Vercel project created & deployed
- [ ] API key added to Vercel environment variables
- [ ] App live at vercel URL
- [ ] Tested on mobile browser
- [ ] Added to home screen as PWA

---

## Troubleshooting

**"npm not found"** → Install Node.js from nodejs.org

**Tailwind styles not working** → Run `npm install` again

**AI not responding** → Check your API key in `.env` or Vercel settings

**App looks broken on mobile** → Make sure viewport meta tag is in index.html ✓

**Build fails** → Run `npm run build` locally first to see errors

---

## Support & Next Steps

- Vercel docs: https://vercel.com/docs
- Capacitor docs: https://capacitorjs.com/docs
- Anthropic API: https://console.anthropic.com
- Tailwind CSS: https://tailwindcss.com/docs

---

*Built with ❤️ — Lovie App v1.0*
