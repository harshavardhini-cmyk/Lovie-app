// 🌸 LOVIE APP — src/App.jsx
// ─────────────────────────────────────────────
// INSTRUCTIONS:
// 1. Delete everything in this file
// 2. Paste the full Lovie component code here
//    (the code Claude generated for you)
// 3. Save the file
// 4. Run: npm run dev
// ─────────────────────────────────────────────

import { useState } from "react";

export default function App() {
  return (
    <div style={{
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      height: "100vh",
      background: "#0a0a0f",
      color: "white",
      fontFamily: "sans-serif",
      flexDirection: "column",
      gap: "16px"
    }}>
      <div style={{ fontSize: 64 }}>🌸</div>
      <h1 style={{ fontSize: 32, fontWeight: 900, margin: 0 }}>Lovie</h1>
      <p style={{ color: "rgba(255,255,255,0.4)", margin: 0 }}>
        Paste your Lovie code into this file to get started!
      </p>
      <p style={{ color: "rgba(255,255,255,0.2)", fontSize: 12 }}>
        See DEPLOY_GUIDE.md for full instructions
      </p>
    </div>
  );
}
